const products = [
  {id:1,name:"SENE. Oversized Tee",price:45,category:"tops",tags:["new","best"],image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=82",desc:"A heavyweight oversized tee with a clean silhouette and signature SENE. finish."},
  {id:2,name:"Essential Hoodie",price:85,category:"tops",tags:["best"],image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=82",desc:"A premium everyday hoodie with a relaxed fit, brushed interior and understated branding."},
  {id:3,name:"Relaxed Cargo Pants",price:95,category:"bottoms",tags:["new"],image:"https://images.unsplash.com/photo-1517438476312-10d79c077509?auto=format&fit=crop&w=900&q=82",desc:"Relaxed utility trousers cut for movement, built with durable fabric and balanced proportions."},
  {id:4,name:"Signature Denim Jacket",price:120,category:"tops",tags:["best"],image:"https://images.unsplash.com/photo-1543076447-215ad9ba6923?auto=format&fit=crop&w=900&q=82",desc:"A structured denim layer designed to age beautifully and anchor every look."},
  {id:5,name:"Premium Linen Shirt",price:75,category:"tops",tags:["new"],image:"https://images.unsplash.com/photo-1603252110481-7ba873bf42ab?auto=format&fit=crop&w=900&q=82",desc:"Soft, airy linen with an easy fit for warm days and effortless styling."},
  {id:6,name:"Wide Leg Trousers",price:90,category:"bottoms",tags:["best"],image:"https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=900&q=82",desc:"Clean wide-leg tailoring with a modern drape and everyday versatility."},
  {id:7,name:"SENE. Graphic Sweatshirt",price:80,category:"tops",tags:["new"],image:"https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=900&q=82",desc:"Soft brushed fleece, bold placement graphic and a relaxed premium fit."},
  {id:8,name:"Classic Logo Cap",price:35,category:"accessories",tags:["best"],image:"https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=900&q=82",desc:"An everyday six-panel cap finished with a minimal embroidered SENE. mark."}
];

let cart = JSON.parse(localStorage.getItem("sene-cart") || "[]");
let favorites = JSON.parse(localStorage.getItem("sene-favorites") || "[]");
let selectedSize = "M";
let currentQuickProduct = null;

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function money(n){return `$${n.toFixed(2)}`}

function saveState(){
  localStorage.setItem("sene-cart", JSON.stringify(cart));
  localStorage.setItem("sene-favorites", JSON.stringify(favorites));
}

function renderProducts(filter="all"){
  const grid = $("#productsGrid");
  let list = products.filter(p => {
    if(filter === "all") return true;
    if(filter === "new" || filter === "best") return p.tags.includes(filter);
    return p.category === filter;
  });
  grid.innerHTML = list.map(p => `
    <article class="product-card reveal visible">
      <div class="product-media">
        ${p.tags.includes("new") ? '<span class="product-badge">NEW</span>' : ""}
        <button class="favorite ${favorites.includes(p.id) ? "active" : ""}" data-favorite="${p.id}" aria-label="Favorite ${p.name}">${favorites.includes(p.id) ? "♥" : "♡"}</button>
        <img src="${p.image}" alt="${p.name}" loading="lazy">
        <div class="product-actions">
          <button data-quick="${p.id}">QUICK VIEW</button>
          <button data-add="${p.id}">ADD TO BAG</button>
        </div>
      </div>
      <div class="product-info"><h3>${p.name}</h3><p>${money(p.price)}</p></div>
    </article>`).join("");
}

function updateCartUI(){
  const count = cart.reduce((sum,i)=>sum+i.qty,0);
  $("#cartCount").textContent = count;
  const items = $("#cartItems");
  if(!cart.length){
    items.innerHTML = `<div style="padding:45px 0;color:#777;font-size:.8rem;text-align:center">Your bag is empty.<br><br><a href="#shop" class="text-link">SHOP THE COLLECTION <span>↗</span></a></div>`;
  } else {
    items.innerHTML = cart.map(item=>{
      const p=products.find(x=>x.id===item.id);
      return `<div class="cart-row">
        <img src="${p.image}" alt="${p.name}">
        <div><h4>${p.name}</h4><p>${money(p.price)}</p><div class="qty-controls">
          <button data-qty="${p.id}" data-change="-1">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-change="1">+</button>
        </div></div>
        <button class="cart-remove" data-remove="${p.id}">REMOVE</button>
      </div>`
    }).join("");
  }
  const subtotal = cart.reduce((sum,i)=>sum + (products.find(p=>p.id===i.id).price*i.qty),0);
  $("#cartSubtotal").textContent = money(subtotal);
}

function showToast(msg){
  const t=$("#toast"); t.textContent=msg; t.classList.add("show");
  clearTimeout(showToast.timer); showToast.timer=setTimeout(()=>t.classList.remove("show"),2200);
}

function addToCart(id,qty=1,size=selectedSize){
  const existing=cart.find(i=>i.id===id && i.size===size);
  if(existing) existing.qty += qty;
  else cart.push({id,qty,size});
  saveState(); updateCartUI(); showToast("Added to your bag");
}

function openCart(){
  $("#overlay").classList.remove("hidden"); $("#cartDrawer").classList.add("open"); $("#cartDrawer").setAttribute("aria-hidden","false"); document.body.classList.add("lock");
}
function closeCart(){
  $("#cartDrawer").classList.remove("open"); $("#overlay").classList.add("hidden"); $("#cartDrawer").setAttribute("aria-hidden","true"); document.body.classList.remove("lock");
}
function openMenu(){
  $("#overlay").classList.remove("hidden"); $("#mobileMenu").classList.add("open"); $("#mobileMenu").setAttribute("aria-hidden","false"); document.body.classList.add("lock");
}
function closeMenu(){
  $("#mobileMenu").classList.remove("open"); $("#overlay").classList.add("hidden"); $("#mobileMenu").setAttribute("aria-hidden","true"); document.body.classList.remove("lock");
}
function openQuick(id){
  currentQuickProduct=products.find(p=>p.id===id);
  $("#quickViewImage").src=currentQuickProduct.image;
  $("#quickViewImage").alt=currentQuickProduct.name;
  $("#quickViewTitle").textContent=currentQuickProduct.name;
  $("#quickViewPrice").textContent=money(currentQuickProduct.price);
  $("#quickViewDescription").textContent=currentQuickProduct.desc;
  $("#quickQty").value=1; selectedSize="M";
  $("#quickViewSizes").innerHTML=["XS","S","M","L","XL","XXL"].map(s=>`<button class="size ${s===selectedSize?"selected":""}" data-size="${s}">${s}</button>`).join("");
  $("#quickViewModal").classList.remove("hidden"); document.body.classList.add("lock");
}
function closeQuick(){ $("#quickViewModal").classList.add("hidden"); document.body.classList.remove("lock"); }

function openSearch(){
  $("#searchPanel").classList.add("open"); $("#searchPanel").setAttribute("aria-hidden","false"); document.body.classList.add("lock"); setTimeout(()=>$("#searchInput").focus(),250); renderSearchResults("");
}
function closeSearch(){
  $("#searchPanel").classList.remove("open"); $("#searchPanel").setAttribute("aria-hidden","true"); document.body.classList.remove("lock");
}
function renderSearchResults(q){
  const query=q.trim().toLowerCase();
  const list=products.filter(p=>!query || `${p.name} ${p.category} ${p.desc}`.toLowerCase().includes(query));
  $("#searchResults").innerHTML=list.length?list.map(p=>`<article class="search-result" data-quick="${p.id}"><img src="${p.image}" alt="${p.name}"><h4>${p.name}</h4><p>${money(p.price)}</p></article>`).join(""):`<p style="grid-column:1/-1;color:#777">No products found.</p>`;
}

function initReveal(){
  const els=$$(".reveal:not(.visible)");
  const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add("visible");io.unobserve(e.target)}}),{threshold:.12});
  els.forEach(el=>io.observe(el));
}

$("#announcementClose").addEventListener("click",()=>$("#announcement").remove());
window.addEventListener("scroll",()=>$("#siteHeader").classList.toggle("scrolled",scrollY>30));
$("#cartOpen").addEventListener("click",openCart);
$("#cartClose").addEventListener("click",closeCart);
$("#overlay").addEventListener("click",()=>{closeCart();closeMenu()});
$("#menuOpen").addEventListener("click",openMenu);
$("#menuClose").addEventListener("click",closeMenu);
$$(".mobile-links a").forEach(a=>a.addEventListener("click",closeMenu));
$("#searchOpen").addEventListener("click",openSearch);
$("#searchClose").addEventListener("click",closeSearch);
$("#searchInput").addEventListener("input",e=>renderSearchResults(e.target.value));

$$(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  $$(".filter").forEach(b=>b.classList.remove("active")); btn.classList.add("active");
  renderProducts(btn.dataset.filter); initReveal();
}));
document.addEventListener("click",(e)=>{
  const fav=e.target.closest("[data-favorite]");
  if(fav){const id=Number(fav.dataset.favorite); favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id]; saveState(); renderProducts($(".filter.active")?.dataset.filter||"all"); showToast(favorites.includes(id)?"Added to favorites":"Removed from favorites");}
  const add=e.target.closest("[data-add]");
  if(add)addToCart(Number(add.dataset.add));
  const quick=e.target.closest("[data-quick]");
  if(quick)openQuick(Number(quick.dataset.quick));
  const remove=e.target.closest("[data-remove]");
  if(remove){cart=cart.filter(i=>i.id!==Number(remove.dataset.remove));saveState();updateCartUI();}
  const q=e.target.closest("[data-qty]");
  if(q){const id=Number(q.dataset.qty),delta=Number(q.dataset.change);const item=cart.find(i=>i.id===id);if(item){item.qty+=delta;if(item.qty<=0)cart=cart.filter(i=>i.id!==id);saveState();updateCartUI();}}
  const cat=e.target.closest("[data-category-link]");
  if(cat){e.preventDefault();const target=cat.dataset.categoryLink;document.querySelector("#shop").scrollIntoView({behavior:"smooth"});setTimeout(()=>{const b=document.querySelector(`.filter[data-filter="${target}"]`);if(b)b.click()},300);}
  const jump=e.target.closest("[data-filter-jump]");
  if(jump){document.querySelector("#shop").scrollIntoView({behavior:"smooth"});setTimeout(()=>document.querySelector('.filter[data-filter="new"]').click(),300)}
  const result=e.target.closest(".search-result[data-quick]");
  if(result){closeSearch();openQuick(Number(result.dataset.quick))}
});

$("#quickViewClose").addEventListener("click",closeQuick);
$("#quickViewSizes").addEventListener("click",e=>{const b=e.target.closest("[data-size]");if(!b)return;selectedSize=b.dataset.size;$$(".size").forEach(s=>s.classList.toggle("selected",s===b))});
$("#quickMinus").addEventListener("click",()=>{const q=$("#quickQty");q.value=Math.max(1,Number(q.value)-1)});
$("#quickPlus").addEventListener("click",()=>{const q=$("#quickQty");q.value=Number(q.value)+1});
$("#quickAdd").addEventListener("click",()=>{addToCart(currentQuickProduct.id,Math.max(1,Number($("#quickQty").value)),selectedSize);closeQuick();openCart();});

$("#newsletterForm").addEventListener("submit",e=>{
  e.preventDefault();
  const email=$("#email").value.trim(), msg=$("#newsletterMessage");
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){msg.textContent="Please enter a valid email address.";msg.style.color="#9b2d2d";return;}
  msg.textContent="Thank you for subscribing to SENE.";msg.style.color="#1f6a3a"; e.target.reset();
});
$("#checkoutBtn").addEventListener("click",()=>showToast("Checkout functionality coming soon."));
$("#accountBtn").addEventListener("click",()=>showToast("Account sign-in coming soon."));

document.addEventListener("keydown",e=>{
  if(e.key==="Escape"){closeSearch();closeQuick();closeCart();closeMenu();}
});

renderProducts(); updateCartUI(); initReveal();
